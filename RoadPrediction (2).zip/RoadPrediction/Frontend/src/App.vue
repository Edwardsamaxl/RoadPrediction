<template>
  <div id="app">
    <AuthContainer />
  </div>
</template>

<script>
import AuthContainer from './components/AuthContainer.vue'

export default {
  name: 'App',
  components: {
    AuthContainer
  }
}
</script>