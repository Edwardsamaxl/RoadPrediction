package org.example.roadprediction;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RoadPredictionApplicationTests {

	@Test
	void contextLoads() {
	}

}
