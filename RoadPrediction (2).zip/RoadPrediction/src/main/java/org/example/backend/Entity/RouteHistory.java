//package org.example.backend.Entity;
//
//import java.sql.Timestamp;
//
//public class RouteHistory {
//    private int userId;
//    private String start;
//    private String end;
//    private Timestamp queryTime;
//
//    public int getUserId() {
//        return userId;
//    }
//
//    public void setUserId(int userId) {
//        this.userId = userId;
//    }
//
//    public String getStart() {
//        return start;
//    }
//
//    public void setStart(String start) {
//        this.start = start;
//    }
//
//    public String getEnd() {
//        return end;
//    }
//
//    public void setEnd(String end) {
//        this.end = end;
//    }
//
//    public Timestamp getQueryTime() {
//        return queryTime;
//    }
//
//    public void setQueryTime(Timestamp queryTime) {
//        this.queryTime = queryTime;
//    }
//}
