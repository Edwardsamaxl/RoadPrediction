package org.example.backend.Controller;

import org.example.backend.Entity.Journey;
import org.example.backend.Entity.Route;
//import org.example.backend.Entity.RouteHistory;
//import org.example.backend.Service.RouteHistoryService;
import org.example.backend.utils.JourneyConverter;
import org.example.backend.utils.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import javax.servlet.http.HttpSession;
import java.sql.Timestamp;
import java.time.LocalDateTime;

@RestController
public class RouteController {

    @Autowired
    private JourneyConverter journeyConverter;

//    @Autowired
//    private RouteHistoryService routeHistoryService;

    private final RestTemplate restTemplate = new RestTemplate();

    @PostMapping("/route")
    public ResponseEntity<Response<Journey>> processRoute(@RequestBody Route route) {
        System.out.println("111");

        // 调用 JourneyConverter 将 Route 转换为 Journey
        Journey journeyWithCoordinates = journeyConverter.convertToJourney(route);

        // 构建要发送的 JSON 数据
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        HttpEntity<Journey> request = new HttpEntity<>(journeyWithCoordinates, headers);

        // 将 Journey 对象发送到 Python 端的 URL
        String pythonEndpoint = "http://127.0.0.1:5000/process_journey";  // Python 服务器地址

        ResponseEntity<Journey> response;
        try {
            response = restTemplate.postForEntity(pythonEndpoint, request, Journey.class);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
        }

        if (response.getStatusCode().is2xxSuccessful()) {
//            // 创建 RouteHistory 对象并记录历史记录
//            RouteHistory routeHistory = new RouteHistory();
//            routeHistory.setUserId(userId); // 设置用户id
//            routeHistory.setStart(route.getStart()); // 设置起点
//            routeHistory.setEnd(route.getEnd()); // 设置终点
//            routeHistory.setQueryTime(Timestamp.valueOf(LocalDateTime.now())); // 设置当前时间
//
//            routeHistoryService.addRouteHistory(routeHistory);

            return ResponseEntity.ok(Response.success(journeyWithCoordinates));
        } else {
            return ResponseEntity.status(response.getStatusCode()).body(null);
        }
    }
}
